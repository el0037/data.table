if(requireNamespace("testthat", quietly = TRUE)){
    library(testthat)
    library(data.table)
    test_package("data.table")
}